'use client'

import { useEffect, useState } from 'react'
import { Check, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  WORKOUT_TYPES,
  WEEKDAYS,
  MONTH_NAMES,
  type WorkoutType,
} from '@/lib/workouts'

interface WorkoutPickerSheetProps {
  date: Date | null
  value: WorkoutType[]
  note: string
  onClose: () => void
  onSave: (types: WorkoutType[], note: string) => void
}

const NOTE_MAX = 200

export function WorkoutPickerSheet({
  date,
  value,
  note,
  onClose,
  onSave,
}: WorkoutPickerSheetProps) {
  const [selected, setSelected] = useState<WorkoutType[]>(value)
  const [text, setText] = useState(note)

  useEffect(() => {
    setSelected(value)
    setText(note)
  }, [value, note, date])

  // 鎖住背景捲動
  useEffect(() => {
    if (date) {
      document.body.style.overflow = 'hidden'
      return () => {
        document.body.style.overflow = ''
      }
    }
  }, [date])

  if (!date) return null

  const toggle = (t: WorkoutType) => {
    setSelected((prev) =>
      prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t],
    )
  }

  const dateLabel = `${date.getFullYear()} 年 ${MONTH_NAMES[date.getMonth()]} ${date.getDate()} 日 · 週${WEEKDAYS[date.getDay()]}`

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      {/* 遮罩 */}
      <button
        aria-label="關閉"
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in"
      />

      {/* 面板 */}
      <div
        role="dialog"
        aria-modal="true"
        aria-label="記錄訓練"
        className="relative w-full max-w-md rounded-t-2xl border border-border bg-popover p-5 pb-8 shadow-2xl animate-in slide-in-from-bottom duration-300 sm:rounded-2xl sm:pb-5"
      >
        <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-border sm:hidden" />

        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">記錄訓練</p>
            <h2 className="mt-0.5 text-lg font-semibold text-pretty">{dateLabel}</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="關閉"
            className="rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mb-3 text-xs text-muted-foreground">選擇訓練部位（可複選）</p>

        <div className="grid grid-cols-2 gap-3">
          {WORKOUT_TYPES.map((t) => {
            const active = selected.includes(t.key)
            return (
              <button
                key={t.key}
                onClick={() => toggle(t.key)}
                aria-pressed={active}
                className={cn(
                  'relative flex h-20 flex-col items-center justify-center gap-1 rounded-xl border-2 text-2xl font-bold transition-all',
                  active
                    ? 'scale-[0.98]'
                    : 'border-border bg-card text-foreground hover:border-muted-foreground/40',
                )}
                style={
                  active
                    ? {
                        backgroundColor: `var(--${t.color})`,
                        color: `var(--${t.fg})`,
                        borderColor: `var(--${t.color})`,
                      }
                    : undefined
                }
              >
                {active && (
                  <span className="absolute right-2 top-2">
                    <Check className="h-4 w-4" strokeWidth={3} />
                  </span>
                )}
                {t.label}
              </button>
            )
          })}
        </div>

        {/* 備註輸入 */}
        <div className="mt-5">
          <div className="mb-2 flex items-center justify-between">
            <label htmlFor="day-note" className="text-xs font-medium text-muted-foreground">
              備註
            </label>
            <span className="font-mono text-[11px] tabular-nums text-muted-foreground/70">
              {text.length}/{NOTE_MAX}
            </span>
          </div>
          <textarea
            id="day-note"
            value={text}
            onChange={(e) => setText(e.target.value.slice(0, NOTE_MAX))}
            placeholder="今天的訓練內容、重量、組數、感受…"
            rows={3}
            className="w-full resize-none rounded-xl border border-border bg-card px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-ring focus:ring-2 focus:ring-ring/30"
          />
        </div>

        <div className="mt-5 flex gap-3">
          <button
            onClick={() => onSave([], '')}
            className="flex-1 rounded-xl border border-border bg-card py-3 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            清除
          </button>
          <button
            onClick={() => onSave(selected, text.trim())}
            className="flex-[1.6] rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            儲存
          </button>
        </div>
      </div>
    </div>
  )
}
